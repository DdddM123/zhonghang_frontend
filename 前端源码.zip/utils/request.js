import axios from "axios";
const baseURL = "http://localhost:8000/";
const instance = axios.create({baseURL});

// 添加相应拦截器
instance.interceptors.request.use(
    result => {
        return result.data;
    },
    error => {
        alert('服务异常');
        return Promise.reject(error);
    }
)

export default instance;