<script setup>

</script>

<template>
  <span>系统管理</span>
</template>

<style scoped>

</style>