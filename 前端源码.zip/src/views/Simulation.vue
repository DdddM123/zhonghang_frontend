<script setup>
import { ref } from 'vue';

// 定义选中的标签页
const activeTab = ref('model');

// 定义仿真模型的步骤
const step = ref('建立模型')
const modelSteps = ref([
  '建立模型',
  '选择方案',
  '导入参数',
  '确定函数',
  '创建完成',
]);
const handleSelect = (key, path) => {
  console.log("选中菜单项：" + key);
}
// 处理标签页点击事件
const handleClick = (tab) => {
  activeTab.value = tab.name;
}

const modelName = ref()
const type = ref()
const options = [
  {
    value: '功能需求',
    label: '功能需求',
  },
  {
    value: '性能需求',
    label: '性能需求',
  },
]
const demand = ref()
const demands = ref([
  {
    value: '需求1',
    label: '需求1',
  },
  {
    value: '需求2',
    label: '需求2',
  },
])
</script>

<template>
  <el-aside width="200px">
    <el-tabs v-model="activeTab" @tab-click="handleClick" type="border-card" stretch>
      <el-tab-pane label="仿真模型" name="model" class="menu-title">
        <el-segmented v-model="step" :options="modelSteps" name="model"
                      direction="vertical" size="large"/>
      </el-tab-pane>
      <el-tab-pane label="仿真结果" name="result" class="menu-title">
        <el-menu default-active="start"
                 class="menu-bar"
                 mode="vertical"
                 @select="handleSelect">
          <el-menu-item index="start">开始仿真</el-menu-item>
          <el-menu-item index="last">最近一次结果</el-menu-item>
          <el-menu-item index="manage">仿真结果管理</el-menu-item>
        </el-menu>
      </el-tab-pane>
    </el-tabs>
  </el-aside>

  <el-container class="container">
    <div v-if="activeTab === 'model'" style="width:100%;">
      <div class="horizontal-container">
        <h2>创建一个新的仿真模型</h2>
      </div>
      <div class="horizontal-container">
        <span>仿真模型名称：</span>
        <el-input
            v-model="modelName"
            style="width: 240px"
            placeholder="请输入仿真模型名称"
            clearable
        />
      </div>
      <div class="horizontal-container">
        <span>关联需求：</span>
        <el-select
            v-model="type"
            placeholder="类型"
            size="default"
            style="width: 120px"
        >
          <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
          />
        </el-select>
        <el-select
            v-model="demand"
            placeholder="需求名称"
            size="default"
            style="width: 240px; margin-left: 10px"
        >
          <el-option
              v-for="item in demands"
              :key="item.value"
              :label="item.label"
              :value="item.value"
          />
        </el-select>
      </div>
      <div class="horizontal-container">
        <el-button type="primary">下一步</el-button>
      </div>
    </div>
    <div v-if="activeTab === 'result'">
      <h2>仿真结果</h2>
    </div>
  </el-container>

</template>

<style scoped>
.el-aside {
  height: 100%; /* 设置侧边栏容器高度为100% */
  background-color: #edeff0; /* 设置背景颜色 */
  border-right: none; /* 移除默认边框 */
  color: black;
  font-size: 16px; /* 你可以根据需要调整这个值 */
}
.el-menu {
  height: 100%; /* 设置菜单高度为100% */
  border-right: none; /* 移除默认边框 */
  background: none;
}
.menu-title {
  font-weight: bold;
  display: flex;
  align-content: center;
  justify-content: center;
  margin: 14px;
}
.el-menu-item {
  color: black;
  font-weight: normal;
  font-size: 18px;
}
.el-menu-item.is-active {
  color: #306bba;
  background: lightgray;
}

.container {
  display: flex;
  flex-direction: column; /* 纵向排列 */
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
}
.horizontal-container {
  display: flex;
  flex-direction: row; /* 横向排列 */
  justify-content: center; /* 子元素之间的间距 */
  width: 50%; /* 根据需要设置宽度 */
  margin-top: 20px;
}
</style>