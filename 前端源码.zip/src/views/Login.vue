<script setup>

</script>

<template>
  <el-row>
    <el-col :span="12" class="bg"></el-col>
    <el-col :span="6" :offset="3" class="form">
      <!--   注册表单   -->
      <span>Login Page</span>
    </el-col>
  </el-row>
</template>

<style scoped>

</style>