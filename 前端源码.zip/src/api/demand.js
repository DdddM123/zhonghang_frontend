import result from "../../utils/request.js";
// 创建需求
export function createDemandService(name, priority, category, description) {
    return  result.post("demand/create_demand", {
        demand_name: name,
        priority: priority,
        category: category,
        description: description
    });
}

// 查找需求
export function searchDemandService(keyword, page, pageSize) {
    return  result.get(`demand/search_demands?keyword=${keyword}&page=${page}&page_size=${pageSize}`);
}

// 分页查询需求
export function listDemandsService(page, pageSize) {
    return  result.get(`demand/demand_list?page=${page}&page_size=${pageSize}`);
}

// 查看需求详情
export function detailDemandService(id) {
    return result.get(`demand/demand_detail?demand_id=${id}`);
}

// 编辑需求
export function editDemandService(id, name, priority, category, description, status, attachment) {
    return  result.post("demand/create_demand", {
        demand_id: id,
        demand_name: name,
        priority: priority,
        category: category,
        description: description,
        status: status,
        attachments: attachment
    });
}

// 删除需求
export function deleteDemandService(id) {
    return  result.post("demand/delete_demand", {
        demand_id: id
    });
}

// 删除指定需求附件
export function deleteDemandAttachmentService(id, key) {
    return  result.post("demand/create_demand", {
        demand_id: id,
        attachment_key: key
    });
}